# The ventilation mode, as described in the Ventmode paper, to Sparse Matrix index.
mode_to_index = {
    0: 0, 
    1: 1, 
    3: 2, 
    4: 3, 
    6: 4
}